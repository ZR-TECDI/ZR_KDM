VERSION = "1.3.0"
//General
author = "ZR Army - Dept. Técnico y Diseño";
OnLoadName = "TEMPLATE ZR";
OnLoadMission = "Uso exclusivo de Zona Roja Army.";
loadScreen = "loadscreen.jpg";
overviewPicture = "loadscreen.jpg";
overviewText = "Misión template para editores.";