class CfgFunctions{
    class ZR{
        tag = "ZR";
        class funciones{
            file = "funciones";

            class pantallaNegraConTexto {};
            class campoMinado {};
            class ataqueMorteros {};
            class checkPlayerAdmins {};
            class cambiarBrilloEnNoche {};
            class construir {};
            class reproducirSonido3D {};
            class dialogoNPC {};
        };
        class helper{
            file = "helper";

            class tomarAsistencia {preInit = 1};
            class escribirDatosDeMision {preInit = 1};
            class encontrarObjetosPorVariable {};
        };
    };    
};