class cfgSounds{
    sounds[] = {};

    // class ambience1
    // {
    //     name="ambience1";
    //     sound[] = {"sounds\ambience1.ogg", 1, 1};
    //     titles[] = {};
    // };
};